NumberofBuffers = 3;
ConcentrationsinPicoMoles = [1 10 100 1000 10000 100000];
l = length(ConcentrationsinPicoMoles);
n = NumberofBuffers;
t = l+n;
M = readmatrix('050622_MBapt_MCH_NPY_100nm.xls');
M = [M; zeros(1,4)];
l = length(M(:,1));
x1 = M(1,2);
x2 = M(2,2);
y1 = M(1,4);
y2 = M(2,4);
y = zeros(t,4);
reading = 1;
count = 1;
line = 1;
C = 10000; %reference current in nA
for i = 1:l-1
    if M(i,3)>M(i+1,3)
        for j = line:i
            if M(j,2)<=C && M(j+1,2)>=C
                x1 = M(j,2);
                x2 = M(j+1,2);
                y1 = M(j,4);
                y2 = M(j+1,4);
                y(reading, count) = 1000*(y1 + ((y2-y1)/(x2-x1))*(C-x1));
                count = count + 1;
            end
        end
        if count >= 5
            reading = reading + 1;
        end
        count = 1;
        line = i;
    end
end
m = mean(y,2);
S = std(y,0,2);
[mini, I] = min(S(1:n));
m= m - m(I);
x= ConcentrationsinPicoMoles;
x = log10(x);
errorbar(x,m(n+1:t),S(n+1:t),"vertical",'o')
title('Voltage Change vs Analyte Conc')
xlabel('Analyte concentration (10^x pM)') 
ylabel('Voltage Change (mV)') 